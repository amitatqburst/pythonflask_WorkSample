# onlinepanipuri
Online PaniPuri

# """
# Flask==2.0.1
# Flask-MySQLdb==0.2.0
# mysql-connector-python==8.0.26
# Flask-Login==0.5.0
# Werkzeug==2.0.1

# """




# Project Structure
# """
# panipuri_website/
# │
# ├── static/
# │   ├── css/
# │   │   └── style.css
# │   └── images/
# │       └── panipuri.jpg
# │
# ├── templates/
# │   ├── base.html
# │   ├── index.html
# │   ├── checkout.html
# │   ├── admin_login.html
# │   └── admin_dashboard.html
# │
# ├── app.py
# ├── database.py
# └─#"""
